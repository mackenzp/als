#include <misc/util/abc_global.h>

ABC_NAMESPACE_IMPL_START

int Abc_RealMain(int argc, char *argv[]);

ABC_NAMESPACE_IMPL_END

int main(int argc, char *argv[])
{
   return ABC_NAMESPACE_PREFIX Abc_RealMain(argc, argv);
}
