/*===================================================================*/
//  
//     place_legalize.c
//
//		Aaron P. Hurst, 2007
//              ahurst@eecs.berkeley.edu
//
/*===================================================================*/

#include <limits.h>
#include <assert.h>

#include "place_base.h"

ABC_NAMESPACE_IMPL_START



// --------------------------------------------------------------------
// legalize()
//
// --------------------------------------------------------------------
void legalize() {
  // UNIMPLEMENTED
}

ABC_NAMESPACE_IMPL_END

